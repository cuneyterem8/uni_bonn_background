public class HelloWorld {
  public static void main (String[] args) { 
    System.out.println("Hello World!"); |\label{line:sample-java-print}|
    // and some other stuff
    for (int i = 0; i < 6; i++)
      foo(i);
  }
}