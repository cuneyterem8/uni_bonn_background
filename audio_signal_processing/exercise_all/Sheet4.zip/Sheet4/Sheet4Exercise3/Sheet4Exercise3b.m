% FASP - Sheet 4 - Exercise 3b
%
% Group Members:
% • Muhammad Ahmed (Matriculation Number: 3304158)
% • Cunyet Erem (Matriculation Number: 32777992)
% • Ali Mohammadi (Matriculation Number: 3289515)
% • Rozhin Bayati (Matriculation Number: 3314202)

Sheet4Exercise3a([1, 2, 3, 4, 10])