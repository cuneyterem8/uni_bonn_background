Group Members (Also mentioned in pdf and Matlab file):
	•	Muhammad Ahmed (Matriculation Number: 3304158)
	•	Cunyet Erem (Matriculation Number: 32777992)
	•	Ali Mohammadi (Matriculation Number: 3289515)
	•	Rozhin Bayati (Matriculation Number: 3314202)


To run “Sheet4Exercise3a”, use “Sheet4Exercise3a(p)” command, where p can be a number or a vector. It will plot unit circles for different values of p as output. For “Sheet4Exercise3b”, use “Sheet4Exercise3b()” as values of p are predefined in it as per required task.