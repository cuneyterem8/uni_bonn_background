% FASP - Sheet 4 - Exercise 3a
%
% Group Members:
% • Muhammad Ahmed (Matriculation Number: 3304158)
% • Cunyet Erem (Matriculation Number: 32777992)
% • Ali Mohammadi (Matriculation Number: 3289515)
% • Rozhin Bayati (Matriculation Number: 3314202)

% Input: p (a single number or vector)
% Output: unit-circles in R2 for different p
%
% To execute entring similar command:
% "Sheet4Exercise3a(p)" where p can be a single number or a vector
function Sheet4Exercise3a(p)
  % Define color pallet to choose unit cirlce plot color from
  color_pallet_for_unit_circles = ['k', 'r', 'y', 'g', 'b', 'm'];
  % Unit circle space
  x = -1:0.01:1;

  % Loop to plot unit circles for different p
  for i = 1:length(p)
    circle_color = color_pallet_for_unit_circles(mod(i, 6) + 1);

    % Plot upper half of unit circle
    y = (1 - abs(x .^ p(i))).^(1/p(i));
    plot(x, y, circle_color)
    hold on

    % Plot lower half of unit circle
    y = -y;
    plot(x, y, circle_color)
    hold on
  end

  % Appropriate title for plots of Unit circle for different p
  title(strcat("Unit Circles in R2 for p = [ ", int2str(p), " ]"))
  hold off