
Assignment3;

Arash Safavi, 
Cüneyt Erem, 
Mayara E. Bonani, 
Guillaume Rouvarel, 
Vardeep Singh

The theoritical part is 'ex3_theoritical.pdf' and,
practical part is 'ex3_practical.ipynb'.

Note from Cüneyt: Hi, from the 3rd assignment, I changed my group and this is my new group, before that I was in other tutor's session, I wanted to inform you.
